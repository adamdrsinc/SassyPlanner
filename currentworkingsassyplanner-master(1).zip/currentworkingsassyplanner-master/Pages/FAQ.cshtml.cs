using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace currentworkingsassyplanner.Pages
{
    public class FAQModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
