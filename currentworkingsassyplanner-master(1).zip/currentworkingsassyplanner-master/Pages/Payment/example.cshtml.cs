using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace currentworkingsassyplanner.Pages.Payment
{
    public class exampleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
